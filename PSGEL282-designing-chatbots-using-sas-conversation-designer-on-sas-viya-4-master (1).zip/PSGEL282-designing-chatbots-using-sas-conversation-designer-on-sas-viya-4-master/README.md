# Designing Chatbots Using SAS Conversation Designer on SAS Viya

PSGEL282: Designing Chatbots Using SAS Conversation Designer on SAS Viya

Important contacts:

| Contact | Team |
| --- | --- |
| Sundaresh Sankaran | Product Management |
| Katie Tedrow | Product Marketing |
| Chris Laurey | Documentation |
| Federica Citterio | Global Technology Practice (GTP) |
| Dan Obermiller | Education (EDU) |
| Teri Patsilaras | Global Enablement & Learning (GEL) |


Here are some great references:

| Reference | Link |
| --- | --- |
| Product Documentation | https://go.documentation.sas.com/?cdcId=cdesignercdc&cdcVersion=default&docsetId=cdesignerwlcm&docsetTarget=home.htm |
| SAS Support: SAS Conversation Designer | https://support.sas.com/en/software/conversation-designer-support.html |
| R&D Confluence Blog | https://rndconfluence.sas.com/confluence/display/NLSTUDIO/2020/12 |
| Sales & Marketing Portal | https://smportal.sas.com/software/conversation-designer/Pages/default.aspx#quickstart |
| SAS Product Management Release Update Videos | https://sas.highspot.com/items/6010370bc79c523cfe078880?lfrm=shp.0 |
| New Demo Experience - December Downloads | https://teams.microsoft.com/l/meetup-join/19%3ameeting_NmNiMzIzMTYtZjEzNi00ZDI0LWIyMDUtZDM2ZmJhZGExMjA2%40thread.v2/0?context=%7b%22Tid%22%3a%22b1c14d5c-3625-45b3-a430-9552373a0c2f%22%2c%22Oid%22%3a%2227d660e2-ee7a-4988-b05b-9ecf3cb32100%22%2c%22IsBroadcastMeeting%22%3atrue%7d |
| SAS conversation Designer Tech Exchange | https://sas.highspot.com/items/5fd0ef34a4dfa002452c0941?lfrm=shp.0 | 
| Frequently Asked Questions | https://sasoffice365.sharepoint.com/:w:/r/sites/MercuryContent/_layouts/15/Doc.aspx?sourcedoc=%7BDE73A6EC-8E9B-43D2-9C86-CA8C0FBC5874%7D&file=SAS%20Conversation%20Designer%20FAQs.docx&wdLOR=c659B7EAB-187B-4038-BA7C-9129DC04D1C7&action=default&mobileredirect=true |