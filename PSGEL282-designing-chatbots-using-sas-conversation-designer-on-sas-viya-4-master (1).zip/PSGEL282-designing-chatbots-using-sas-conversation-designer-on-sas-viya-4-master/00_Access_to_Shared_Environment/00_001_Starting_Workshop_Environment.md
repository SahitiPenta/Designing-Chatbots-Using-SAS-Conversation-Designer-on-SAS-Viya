![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

* [Register yourself to be part of the STICExnetUsers group](#register-yourself-to-be-part-of-the-sticexnetusers-group)
* [Reserve the Client Machine](#reserve-the-client-machine)
* [Accessing the Client Machine](#accessing-the-client-machine)
* [Find Your Assigned Userid](#find-your-assigned-userid)
* [Accessing Hands-on Exercises](#accessing-hands-on-exercises)
  * [Access via Virtual Learning Environment (VLE)](#access-via-virtual-learning-environment-vle)
  * [Access via Reserved Client Machine](#access-via-reserved-client-machine)

# Getting Started with the Workshop Shared Environment

For this SAS Viya 4 Workshop, you will have access to a shared SAS Viya 4 environment. The environment includes one dedicated Windows client machine and several shared Linux and Windows machines.

Your access into the environment will be through the Windows machine. From that windows machine, you will use the browser and terminal emulation software to access the shared environment.

## Register yourself to be part of the STICExnetUsers group

* If you are not yet a member of the **STICExnetUsers** group, you need to join it.
  * [Click here](mailto:dlistadmin@wnt.sas.com?subject=Subscribe%20STICEXNETUsers) to prepare an email request to join **STICExnetUsers** group
  * Send the email as-is, without any changes
* Once the email is sent, you will be notified via email of the creation of the account.
* Your account membership should be updated and ready for use within 1 hour
* Sometimes, it takes much longer than 1 hour for this group membership to propagate through the network.
* To expedite the group membership, simply log out of the SAS network and log back in).
* Until the group membership change occurs, you won't be able reserve the environment.

## Reserve the Client Machine

* [Book](http://race.exnet.sas.com/Reservations?action=new&imageId=1764604&imageKind=I&comment=VIYA4_Client%20_WKSHP_PSGEL282_INT_&purpose=P&schedtype=SchedTrainEDU&startDate=now&endDateLength=4) the client machine.

* Hit enter, making no changes. You have 4 working days to complete the exercises, and that should be sufficient. If you need a time extension to complete the exercises, please [contact GEL](mailto:GEL_VLE@wnt.sas.com).

    <p><details>
    <summary>Click to expand/collapse to see how this is done</summary>

    ![book](https://gelgitlab.race.sas.com/GEL/workshops/_assets/-/raw/main/img/book_machine.gif)

    </details></p>


## Accessing the Client Machine

* You will receive an email when your client machine is ready. The email shows the machine name assigned to you. Use Remote Desktop on your local machine to connect to the Windows Client machine using the following credentials.
  * User: `.\student`
  * Password: `Metadata0`

    <p><details>
    <summary>Click to expand/collapse to see how this is done</summary>

    ![Access Client Machine](https://gelgitlab.race.sas.com/GEL/workshops/_assets/-/raw/main/img/RDP.gif)

    </details></p>

## Find Your Assigned Userid

* The workshop environment is a shared environment. It is very important that you use your assigned SAS Viya User account (aka gatedemo userid).
When your Windows client machine starts, a Connection Guide is copied to the Desktop. This file contains detailed information about the shared environment as well as the assigned SAS Viya User account to use. Note: you can refer to the filename to quickly remind yourself of your assigned User account. In the sample below, the assigned userid is *`gatedemo010`* (yours will more than likely be different).
* The password for your assigned gatedemo id is lnxsas (starts with a lowercase "L")

* If any credentials other than your gatedemo account are needed, you will be informed of them in the hands-on exercises instructions.

    <p><details>
    <summary>Click to expand/collapse to see how this is done</summary>

    ![Find Userid](https://gelgitlab.race.sas.com/GEL/workshops/_assets/-/raw/main/img/Viya4Userid.gif)

    </details></p>

## Accessing Hands-on Exercises

All Hands-On Exercises are stored in [gitlab projects](https://gelgitlab.race.sas.com/GEL/workshops).

### Access via Virtual Learning Environment (VLE)
In the VLE there are direct links to the hands-on exercises. Simply click on the desired link.

![VLE links to Hands-on Exercises](https://gelgitlab.race.sas.com/GEL/workshops/_assets/-/raw/main/img/VLELink.png)

### Access via Reserved Client Machine

At times it may be easier and/or necessary to access the hands-on exercise and associated assets directly from the reserved client machine. A link to the Hands-on Exercises is found on the Desktop of the client machine. Click on the Hands-On Exercises icon on the desktop to be directed to the appropriate Gitlab repository that contains the documents for this workshop. From this client machine you can copy+paste the instructions directly from the hands-on document.

![Hands-On Icon](https://gelgitlab.race.sas.com/GEL/workshops/_assets/-/raw/main/img/Hands-On_Exercises_Desktop_Icon.png)

  <p><details>
  <summary>Click to expand/collapse to see how this is done</summary>

  ![Hands-On Access on Client](https://gelgitlab.race.sas.com/GEL/workshops/_assets/-/raw/main/img/ClientGitlab.gif)

  </details></p>