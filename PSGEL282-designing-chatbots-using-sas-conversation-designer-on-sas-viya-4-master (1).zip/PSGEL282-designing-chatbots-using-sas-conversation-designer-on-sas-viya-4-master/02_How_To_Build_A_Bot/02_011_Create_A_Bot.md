![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# Create A Bot

- [Introduction](#introduction)
- [Log into SAS Drive](#log-into-sas-drive)
- [Open SAS Conversation Designer](#open-sas-conversation-designer)
- [Create a new bot](#create-a-new-bot)

## Introduction

In this exercise you will create a bot to answer questions about auto insurance.  

This example is modified from SAS Documentation's:  https://go.documentation.sas.com/?cdcId=cdesignercdc&cdcVersion=v_003&docsetId=cdesignerug&docsetTarget=p0iweu4dundppfn1cv17q8as3ijz.htm&locale=en  

## Log into SAS Drive

Be sure that you have logged onto your RACE server using Remote Desktop.  Use the localhost\ **Student** account and password **Metadata0** (that is a zero at the end)

![RemoteDesktop](../images/00/RemoteDesktop.png)

1. Open the Google Chrome browser on your Windows RACE Image. Select one of the **Viya Links** grouping bookmarks.

1. Select **SAS Drive**.
   
   ![SASDrive](../images/00/SASDrive.png)

1. Enter the following:
    - User ID:  ***gatedemoxxx*** (Where **xxx** is your assigned User ID for the class)
    - Password: ***lnxsas*** (Where l is a lower case L)
1. Click **Sign In**.

## Open SAS Conversation Designer

1. From the side **Application Menu**, select **Build Conversational Flows**.

    ![SCD](../images/00/BuildConversationalFlows.png)

## Create a new bot

1. Use the **New Bot** button and name your bot **GateDemoXXX Auto Insurance Policies**.  Where **XXX** is your assigned user ID for the class.

    ![NewBot](../images/02/011/image001.png)