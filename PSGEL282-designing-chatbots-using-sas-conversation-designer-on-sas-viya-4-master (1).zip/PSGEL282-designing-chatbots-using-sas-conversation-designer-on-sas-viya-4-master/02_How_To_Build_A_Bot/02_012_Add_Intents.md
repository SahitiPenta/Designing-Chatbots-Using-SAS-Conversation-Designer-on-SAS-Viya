![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# Add Intents

- [Introduction](#introduction)
- [Add intents](#add-intents)

## Introduction

In this exercise you will continue to configure the **Auto Insurance Policies** bot from the previous exercise.  If you need to, please revisit the earlier instructions to complete those steps.

Now we will add intents to our bot.  Recall that an intent is a predefined user goal that your bot seeks to help you accomplish.

## Add intents

1. With the **GateDemoXXX Auto Insurance Policies** bot open, click on the **Intents** tab.  Then use the **New Intent** button to add the **Claim payment timeline** intent.  Press the *Enter* key to save the intent.  

    ![NewIntent](../images/02/012/image001.png)

    ![ClaimPaymentTimeline](../images/02/012/image002.png)

1. Repeat this process for the following values:

    | Intent | 
    | --- |
    | Claim payment timeline |
    | Collision vs Comprehensive explained |
    | Coverage for property stolen from cars |
    | Deductible explained |
    | Insurance quote |
    | Small talk (thank you) |

    The **Intents** tab should look like this:

    ![AllIntents](../images/02/012/image003.png)