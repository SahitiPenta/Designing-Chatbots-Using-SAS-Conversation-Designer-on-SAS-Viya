![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# Create Dialogues: Insurance Quote With Buttons And VA Report

- [Introduction](#introduction)
- [Add a dialogue for the Insurance quote Intent](#add-a-dialogue-for-the-insurance-quote-intent)
- [Configure the User Input node](#configure-the-user-input-node)
- [Configure the Text Response node](#configure-the-text-response-node)
- [Configure the Buttons node](#configure-the-buttons-node)
- [Add Yes/No Intents](#add-yesno-intents)
- [Add the No User Input node](#add-the-no-user-input-node)
- [Add the No Text Response](#add-the-no-text-response)
- [Add the Yes User Input node](#add-the-yes-user-input-node)
- [Add the Yes Text Response](#add-the-yes-text-response)
- [Add a Text Input node](#add-a-text-input-node)
- [Add a Text Response](#add-a-text-response)
- [Add a Report Source node and review the VA Report](#add-a-report-source-node-and-review-the-va-report)
- [Add a Report Filter node](#add-a-report-filter-node)
- [Add a Report Visualization Data node](#add-a-report-visualization-data-node)
- [Add Text Response node to format VA Report Visualization Data](#add-text-response-node-to-format-va-report-visualization-data)
- [Add Report Prompts node](#add-report-prompts-node)
- [Add Report Visualization Images node](#add-report-visualization-images-node)
- [Test the dialogue](#test-the-dialogue)


## Introduction

In this exercise you will continue to configure the **Auto Insurance Policies** bot from the previous exercises.  If you need to, please revisit the earlier instructions to complete those steps.

These steps will walk through creating a dialogue for the **Insurance quote** intent with a **Buttons**, **VA Report Data** and **VA Report Image**.

## Add a dialogue for the Insurance quote Intent

1. From the **Dialogues** tab, click **New Dialogue**.  Name the dialogue **Insurance quote**.

1. In this dialogue we will need to add many nodes, but because of the button branch we will pause to configure one side then the other.

    To start, add the following nodes after the **User Input** node:
    - **Text Response** (**Bot Response > Text Response**)
    - **Buttons** (**Bot Response > Buttons**)

## Configure the User Input node

1. With the **User Input** node selected, use the right pane to configure this dialogue to the matching **Insurance quote** intent.

    ![UserInput](../images/02/019/image001.png)

## Configure the Text Response node

1. Select the **Text Response** node and enter the following in the editor:

    | Text Response |
    | --- |
    | $userName, I can help provide an Insurance Quote, please confirm that you are over 18 years of age. |

## Configure the Buttons node

1. Select the **Buttons** node.  Configure the following:

    | Label | Display Text |
    | --- | --- |
    | Yes | Yes, I'm over 18 years old |
    | No | No, I'm not over 18 years old|

    ![Buttons](../images/02/019/image002.png)

## Add Yes/No Intents

1. In order for the bot to capture the button input, we will need to add **Intents** for both the Yes and No selections.

1. From the **Intents** tab, add the following

    | New Intent | Utterance |
    | --- | --- |
    | Yes, I am over 18 | Yes |
    | No, I am under 18 | No |

    Be sure when you add the utterance "Yes" or "No" to still click **Analyze** and **Apply** so that it gets added to the intent properly.  However, notice that we do not need to identify any entities.

    ![YesIntent](../images/02/019/image003.png)

    ![NoIntent](../images/02/019/image004.png)

## Add the No User Input node

1. Back on the **Dialogues** tab, select the **Buttons** node, add a **User Input** node below.

1. Configure the **User Input** node:

    | Property | Value |
    | --- | --- |
    | Name | Match "No, I am under 18" |
    | Intent | No, I am under 18 |

    ![MatchNo](../images/02/019/image005.png)

## Add the No Text Response

1. With the **Match "No, I am under 18" User Input** node selected, add a **Text Response** node below.  

    Name the node:  **Response (Return with parental guidance)**

1. Add the following text to the editor:

    | Text Response |
    | --- |
    | Insurance qualifications require an adult present.  Please come back again with parental guidance. |

    ![NoResponse](../images/02/019/image006.png)

## Add the Yes User Input node

1. Go back up and select the **Buttons** node.  This is a new option, select **Add branching node > User Input**.

1. Configure the **User Input** node:

    | Property | Value |
    | --- | --- |
    | Name | Match "Yes, I am over 18" |
    | Intent | Yes, I am over 18 |

    ![YesInput](../images/02/019/image009.png)

## Add the Yes Text Response

1. With the **Match "Yes, I am over 18" User Input** node selected, add a **Text Response** node below.  

    Name the node:  **Response (What state do you live in?)**

1. Add the following text to the editor:

    | Text Response |
    | --- |
    | Okay, I can help you with your quote today.  What state do you live in? |

    ![YesResponse](../images/02/019/image010.png)

## Add a Text Input node

1. Again using a rudimentary prompt/matching criteria we will store the incoming value directly.  With the **Response (What state do you live in?)** selected, add a **Text Input** node below.

1. Configure the **User Input** node:

    | Property | Value |
    | --- | --- |
    | Name | Text Input (TypedInsuranceState) |
    | Parameter name | TypedInsuranceState |

    ![StateInput](../images/02/019/image011.png)

## Add a Text Response

1. Add a **Text Response** node below with the following text:

    | Text Response |
    | --- |
    | I will now look up the insurance coverage range for $TypedInsuranceState |

    ![RepeateBackState](../images/02/019/image012.png)

## Add a Report Source node and review the VA Report

1. Now we're getting to the exciting part.  Before we can reference a VA Report, we need to load it as a source to the bot.  

    I've already created the VA Report you will be using.  Let's take a quick look at it.  Use the **Application Menu** and select **Explore and Visualize**. 

    Use the **All Reports** tab and navigate to:  **All Reports > gelcontent > Demo > VISUAL > Reports > State Insurance Quotes**.

    ![VAReportLocation](../images/02/019/image007.png)

1. Open the VA Report **State Insurance Quotes**.  

    We will prompt the user for a state name and return the range of insurance coverage.  Notice the name of the report object - we will need that later.  

    ![VAReportObject](../images/02/019/image008.png)

    We will also display a bar chart with dynamic highlighting.  Notice that this drop-down list control is not a filter but is configured to drive a dynamic display rule.  

    ![VABarObject](../images/02/019/image013.png)

1. Toggle back to **Build Conversational Flows**.  Select the **Text Response** node and add a **Report Source** node below.

    Configure the node as below:

    | Property | Value |
    | --- | --- |
    | Name | Report Source (StateInsQuotesReport) |
    | Source | Report |
    | Report name | State Insurance Quotes (use the Browse button to navigate to **All Reports > gelcontent > Demo > VISUAL > Reports > State Insurance Quotes**) |
    | Output-report parameter name | StateInsQuotesReport|

    >Hint:  Notice I'm still keeping with my trick of adding the output parameter to the name of the node.  This helps to follow which nodes output what values.

    ![ReportSource](../images/02/019/image014.png)

## Add a Report Filter node

1. The previous node essentially loaded the VA Report as a source of data for the bot to reference.  Now we will need to pass the state filter to the report output.

    With the **Report Source** node selected, add a **Report Filters** node below.  Configure the following:

    | Property | Value |
    | --- | --- |
    | Name | Report Filters (StateInsQuoteFiltered) |
    | Input-report parameter name | StateInsQuotesReport |
    | Filters | Visualization:  List table - State 1 |
    | Filters | Left Operand: State |
    | Filters | Operator: = (is equal to) |
    | Filters | Right operands: $TypedInsuranceState |
    | Output-report parameter name | StateInsQuoteFiltered |

    ![FilterWithState](../images/02/019/image015.png)

## Add a Report Visualization Data node

1. Now that we have passed the filter to the report source, we need to grab that filtered result.  

    With the **Report Filters** node selected, add a **Report Visualization Data** node below.  Configure the following:

    | Property | Value |
    | --- | --- |
    | Name | Report Visualization Data (StateInsQuoteRange) |
    | Input-report parameter name | StateInsQuoteFiltered |
    | Visualization | List table - State 1 |
    | Output-data parameter name | StateInsQuoteRange |

    ![VARptData](../images/02/019/image016.png)

## Add Text Response node to format VA Report Visualization Data

1. Now we need to use VTL to format the JSON result set.  With the **Report Visualization Data** node selected, add a **HTML Response** node below.

    Add the following to the editor.  Make sure you copy all of the text to the right!

    ```
    The insurance coverage range for $TypedInsuranceState is $NumberTool.currency($StateInsQuoteRange.get("State Minimum Annual Rate").get(0)) - $NumberTool.currency($StateInsQuoteRange.get("Full Coverage Annual Rate").get(0))

    Here is how the average of $TypedInsuranceState coverage compares to other states' averages
    ```

    ![VAResponse](../images/02/019/image017.png)

## Add Report Prompts node

1. Let's also return one of the VA Report's visuals.  Remember I mentioned about the drop-down list control which will highlight the selected state's average compared to the rest.  

    Instead of passing a filter of state, we will merely be passing it to a parameter in the VA Report to dynamically update the bar chart and return it to the bot.  

    With the **HTML Response** node selected, add a **Report Prompts** node.  Right now we will pass our state value to the parameter assigned to the drop-down list control since there is a bit of a glitch in the bot being able to find the control object name directly.  (Should be corrected in next release.)

    Configure the **Report Prompts** node as below:

    | Property | Value |
    | --- | --- |
    | Name | Report Prompts (HighlightedStateInsRpt) |
    | Input-report parameter name | StateInsQuotesReport |
    | Prompts | Prompt name: SelectedState |
    | Prompts | Prompt values: $TypedInsuranceState |
    | Output-data parameter name | HighlightedStateInsRpt |

    ![RptPrompt](../images/02/019/image018.png)

## Add Report Visualization Images node

1. Now let's add the VA Report visual.  With the **Report Prompts** node selected, add a **Report Visualization Images** (under **Bot Response**) node below.  

    Configure as below:

    | Property | Value |
    | --- | --- |
    | Name | Report Visualization Images |
    | Visualization Images | Input-report parameter name: HighlightedStateInsRpt |
    | Visualization Images | Visualization: Bar - State 1 |

    ![VARptVisual](../images/02/019/image019.png)

## Test the dialogue

1. Use the **Try It Now** window to test the flow!

    | Valid state values |
    | --- |
    | New Jersey |
    | Arizona |
    | Kansas |
    | Hawaii |
    | Nebraska |
    | North Carolina |
    | Virginia |

    **No Flow**

    ![NoFlow](../images/02/019/image020.png)

    **Yes Flow**

    ![YesFlow](../images/02/019/image021.png)



