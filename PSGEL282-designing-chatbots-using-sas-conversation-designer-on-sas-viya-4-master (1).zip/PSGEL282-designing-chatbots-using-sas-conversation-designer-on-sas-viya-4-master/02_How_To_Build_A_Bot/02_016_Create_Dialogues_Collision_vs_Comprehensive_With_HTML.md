![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# Create Dialogues: Collision vs Comprehensive With HTML

- [Introduction](#introduction)
- [Add a dialogue for the Collision vs Comprehensive explained Intent](#add-a-dialogue-for-the-collision-vs-comprehensive-explained-intent)
- [Configure the User Input node](#configure-the-user-input-node)
- [Configure the HTML Response node](#configure-the-html-response-node)
- [Test the dialogue](#test-the-dialogue)

## Introduction

In this exercise you will continue to configure the **Auto Insurance Policies** bot from the previous exercises.  If you need to, please revisit the earlier instructions to complete those steps.

These steps will walk through creating a dialogue for the **Collision vs Comprehensive explained** intent and with HTML in the response.

## Add a dialogue for the Collision vs Comprehensive explained Intent

1. From the **Dialogues** tab, click **New Dialogue**.  Name the dialogue **Collision vs Comprehensive explained**.

1. In this dialogue we will need to add the **HTML Response** node.  

    From the User Input node, use the overflow menu (the vertical ellipsis) then **Add node below > Bot Response > HTML Response**.

    ![CvCDialogue](../images/02/016/image001.png)

## Configure the User Input node

1. With the **User Input** node selected, use the right pane to match this dialogue to the matching **Collision vs Comprehensive explained** intent.  

    ![UserInput](../images/02/016/image002.png)

## Configure the HTML Response node

1. In this example, we will be using plain HTML in the response.  You could use a code response to populate the table values if needed.

    Copy the following code to the **HTML Response editor**.

    ```
    <style>
    table {
         margin: 20px;
    }
    table, th, td {
        border: 1px solid black;
        border-collapse: collapse;      
    }
    th, td {
        padding: 5px
    }
    </style>
    <table>
    <tr>
     <th>Collision Coverage</th>
     <th>Comprehensive Coverage</th>
    </tr>
    <tr>
     <td>Physical damage to your auto caused by a collision with another car or object.</td>
     <td>Physical damage to your auto, including fire, theft, vandalism, and broken glass.</td>
    </tr>
    </table>
    ```

## Test the dialogue

1. Use the **Try It Now** window to see if the table formatting is acceptable.

    What’s the difference between collision and comprehensive?

    ![TryItNow](../images/02/016/image003.png)