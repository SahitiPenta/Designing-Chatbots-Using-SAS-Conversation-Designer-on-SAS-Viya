![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# Create Dialogues: Coverage Stolen Property With Text

- [Introduction](#introduction)
- [Add a dialogue for the Coverage for property stolen from cars Intent](#add-a-dialogue-for-the-coverage-for-property-stolen-from-cars-intent)
- [Configure the User Input node](#configure-the-user-input-node)
- [Configure the Text Response node](#configure-the-text-response-node)
- [Add a Pause node](#add-a-pause-node)
- [Test the dialogue](#test-the-dialogue)

## Introduction

In this exercise you will continue to configure the **Auto Insurance Policies** bot from the previous exercises.  If you need to, please revisit the earlier instructions to complete those steps.

These steps will walk through creating a dialogue for the **Coverage for property stolen from cars** intent with Text response.

## Add a dialogue for the Coverage for property stolen from cars Intent

1. From the **Dialogues** tab, click **New Dialogue**.  Name the dialogue **Coverage for property stolen from cars**.

1. In this dialogue we will need to add the **Text Response** node.  

    From the **User Input** node, use the overflow menu (the vertical ellipsis) then **Add node below > Bot Response > Text Response**.

    ![StoleDialogue](../images/02/017/image001.png)

## Configure the User Input node

1. With the **User Input** node selected, use the right pane to match this dialogue to the matching **Coverage for property stolen from cars** intent.

    ![UserInput](../images/02/017/image002.png)

## Configure the Text Response node

1. This is going to be a straight forward text response from the bot.  Copy the below text into the **Text Response editor**.

    | Text Response |
    | --- |
    | If the stolen items are permanently installed in the car and you have comprehensive (other than collision) coverage, the loss is covered under your auto policy. However, if the stolen property is something that you put in your car, such as CDs or a GPS, this is usually covered under a home policy, as part of your personal property coverage. |

## Add a Pause node

1. This is a lot of text and to mimic a more human-like interaction we should probably slow down the response to appear as if the bot is typing.

1. From the **Text Response** node, use the overflow menu then **Add node above > Bot Response > Pause**.

    Select the **Show typing indicator** box.

    ![AddPause](../images/02/017/image003.png)

## Test the dialogue

1. Use the **Try It Now** window to test the dialogue.  

    >Hint:  Forgot the utterance to trigger the correct response?  Toggle to the **Intents** or **Utterances** tab to jog your memory.