![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# Add Utterances And Entities

- [Introduction](#introduction)
- [Add Utterances and Entities for Claim payment timeline](#add-utterances-and-entities-for-claim-payment-timeline)
- [Add Utterances and Entities for Collision vs Comprehensive explained](#add-utterances-and-entities-for-collision-vs-comprehensive-explained)
- [Add Utterances and Entities for Coverage for property stolen from cars](#add-utterances-and-entities-for-coverage-for-property-stolen-from-cars)
- [Add Utterances and Entities for Deductible explained](#add-utterances-and-entities-for-deductible-explained)
- [Add Utterances and Entities for Insurance quote](#add-utterances-and-entities-for-insurance-quote)
- [Add Utterances and Entities for Small talk (thank you)](#add-utterances-and-entities-for-small-talk-thank-you)

## Introduction

In this exercise you will continue to configure the **Auto Insurance Policies** bot from the previous exercises.  If you need to, please revisit the earlier instructions to complete those steps.

Now we will add utterances and entities to the bot.  Recall that utterances are the training data for the bot to attempt to understand the incoming requests.  Try to keep the sentences short and mimic how the request would be asked.  We will identify key terms, called entities, to help differentiate utterances.

## Add Utterances and Entities for Claim payment timeline

1. From the **Intents** tab, click the **Claim payment timeline** intent.

1. Type or copy the following utterance:
   
   | Utterance |
   | ---| 
   | How long will it take before I receive payment for the claim?|


1. Click **Analyze**.

    ![ClaimPaymentUtterance](../images/02/013/image001.png)

1. Next we will identify key terms, entities, that would help identify an incoming request to this utterance and ultimately intent.  
   
   Double-click on the term **claim**.  Then create a **New entity...** with the **Exact Matcher type** also named **claim**.  Keep the same description for **Label**.  

   ![Claim](../images/02/013/image002.png)

1. Next, repeat the entity creating steps for **payment**.
   
   Click **Apply** once complete.

    ![Payment](../images/02/013/image003.png)

1. Here is what you just completed:

    | Intent | Utterance | Entity | Matcher Type| Label |
    | --- | --- | --- | ---- | --- |
    | Claim payment timeline | How long will it take before I receive payment for the claim? | claim | Exact | claim |
    | " | " | payment | Exact | payment |

    ![Utterance1](../images/02/013/image004.png)

1. Repeat these steps for the second utterance for **Claim payment timeline**.

    Copy and paste the utterance below and click **Analyze**.  

    Notice that when you double-click on the entities that you can reuse what we have already identified in the previous step.  

    | Intent | Utterance | Entity | Matcher Type| Label |
    | --- | --- | --- | ---- | --- |
    | Claim payment timeline | How quickly do the payments for claims get processed? | claim | Exact | claim |
    | " | " | payments - match to payment | Exact | payment |

    ![Utterance2](../images/02/013/image005.png)

1. Add a third utterance for **Claim payment timeline**.

    | Intent | Utterance | Entity | Matcher Type| Label |
    | --- | --- | --- | ---- | --- |
    | Claim payment timeline | When will my claim be paid? | claim | Exact | claim |
    | " | " | paid - match to payment | Exact | payment |

    Did you have to manually highlight both claim and paid?

   <p><details>
   <summary>Click to expand/collapse for solution</summary>

   **Solution:** You did not have to highlight claim because it was matched automatically.  
   </details></p>
   
1. Click on the **Utterances** tab.  Notice the utterances and entities we just created.  Does everything appear correct like in the below screenshot?

    ![UtterancesTab](../images/02/013/image006.png)

## Add Utterances and Entities for Collision vs Comprehensive explained

1. Click back on the **Intents** tab.  Now highlight the **Collision vs Comprehensive explained** intent.  

1. Configure the following utterances and entities:

    | Intent | Utterance | Entity | Matcher Type| Label |
    | --- | --- | --- | ---- | --- |
    | Collision vs Comprehensive explained | How is collision coverage different from comprehensive coverage? | collision coverage | Exact | collision coverage |
    | " | " | comprehensive coverage | Exact | comprehensive coverage |
    | --- | --- | --- | ---- | --- |
    | Collision vs Comprehensive explained | What’s the difference between collision and comprehensive? | collision - maps to collision coverage | Exact | collision coverage |
    | " | " | comprehensive - maps to comprehensive coverage | Exact | comprehensive coverage |

1. Before we add another utterance, let's test the **Try It Now** window.

    ![CollVSComp](../images/02/013/image007.png)

1. From the **Try It Now** window, click on the **Utterance** tab.  Type and press *Enter*:  What’s the difference between collision coverage and comprehensive coverage?

    Did the utterance map to the correct entity?  Yes!  That means we do not need to add this utterance as training data since the bot will correctly map this one.

    >Hint: If you did not get this mapping - try closing the bot and opening it again.  Test with the exact utterances that were used until you get successful mapping then try again.

    ![TestUtterance](../images/02/013/image008.png)

    Can you think of an utterance that doesn't map that we could add?  Try a few out.

   <p><details>
   <summary>Click to expand/collapse for solution</summary>

   **Solution:** How are collision and comprehensive different?
   </details></p>

## Add Utterances and Entities for Coverage for property stolen from cars

1. From the **Intents** tab, highlight the **Coverage for property stolen from cars** intent.  

1. Configure the following utterances and entities:

    | Intent | Utterance | Entity | Matcher Type| Label |
    | --- | --- | --- | ---- | --- |
    | Coverage for property stolen from cars | Does the policy cover property stolen from my car? | cover - name it coverage | Exact | coverage |
    | " | " | stolen - name it theft | Exact | theft |
    | --- | --- | --- | ---- | --- |
    | Coverage for property stolen from cars | If something is stolen from my car, is that covered? | covered - map to coverage | Exact | coverage |
    | " | " | stolen - map to theft | Exact | theft |

1. Configuration should look like this:
   
    ![PropertyFromCars](../images/02/013/image009.png)

## Add Utterances and Entities for Deductible explained

1. From the **Intents** tab, highlight the **Deductible explained** intent.  

1. Configure the following utterances and entities:

    | Intent | Utterance | Entity | Matcher Type| Label |
    | --- | --- | --- | ---- | --- |
    | Deductible explained | What is a deductible? | deductible | Lemma | deductible |

1. Configuration should look like this:

    ![Deductible](../images/02/013/image010.png)

## Add Utterances and Entities for Insurance quote

1. From the **Intents** tab, highlight the **Insurance quote** intent.  

1. Configure the following utterances and entities:

    | Intent | Utterance | Entity | Matcher Type| Label |
    | --- | --- | --- | ---- | --- |
    | Insurance quote | How much does insurance cost? | insurance | Exact | insurance |
    | " | " | cost - name it quote | Exact | quote |
    | --- | --- | --- | ---- | --- |
    | Insurance quote | I would like an insurance quote | insurance | Exact | insurance |
    | " | " | quote | Exact | quote |

1. Configuration should look like this:

    ![Quote](../images/02/013/image011.png)

## Add Utterances and Entities for Small talk (thank you)

1. From the **Intents** tab, highlight the **Small talk (thank you)** intent.  

1. Configure the following utterances and entities:

    | Intent | Utterance | Entity | Matcher Type| Label |
    | --- | --- | --- | ---- | --- |
    | Small talk (thank you) | Thank you | thank you | Exact | thank you |

1. Configuration should look like this:
   
   ![SmallTalk](../images/02/013/image012.png)

   