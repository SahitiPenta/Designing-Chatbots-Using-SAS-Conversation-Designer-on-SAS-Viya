![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# Create Dialogues: Small Talk

- [Introduction](#introduction)
- [Create a Small Talk dialogue](#create-a-small-talk-dialogue)
- [Add a Text Response node](#add-a-text-response-node)



## Introduction

In this exercise you will continue to configure the **Auto Insurance Policies** bot from the previous exercises.  If you need to, please revisit the earlier instructions to complete those steps.

These steps will walk through creating a **Small Talk** dialogue.

## Create a Small Talk dialogue

1. From the **Small Talk** tab, click **New Small Talk**.  Name it:

    ```
    Small talk (thank you)
    ```
    
    ![NewSmallTalk](../images/02/01B/image001.png)

## Add a Text Response node

1. From the **User Input** node, add below a **Text Response** node.  Add the following into the editor:

    ```
    You're welcome!
    ```

    ![SmallTalkReply](../images/02/01B/image002.png)
