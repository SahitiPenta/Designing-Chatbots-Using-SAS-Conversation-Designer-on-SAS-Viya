![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# Create Dialogues: Welcome With VTL

- [Introduction](#introduction)
- [Add a dialogue to Welcome the user](#add-a-dialogue-to-welcome-the-user)
- [Configure the Text Response node](#configure-the-text-response-node)
- [Test the dialogue](#test-the-dialogue)


## Introduction

In this exercise you will continue to configure the **Auto Insurance Policies** bot from the previous exercises.  If you need to, please revisit the earlier instructions to complete those steps.

These steps will walk through creating a welcome dialogue that picks between a set of different greetings.

## Add a dialogue to Welcome the user

1. From the **Dialogues** tab, click **New Dialogue**.  Name the dialogue **Welcome**.

1. In this dialogue we will need the two nodes:
    - **Start-Chat Event**
    - **Text Response**

    For the **Start-Chat Event** node, use the overflow menu (the vertical ellipsis) then **Add node above > Event > Start-Chat Event**.

    Delete the **User Input** node using the overflow menu.

    For the **Text Response** node, use the overflow menu then **Add node below > Bot Response > Text Response**.

    ![WelcomeNodes](../images/02/014/image001.png)

## Configure the Text Response node

1. Select the **Text Response** node.  Here we will use one of SAS's Conversation Designer VTL Tools, **$DataTool**, in the response.  

    Copy the below code to the **Text Response editor**.

    | Text Response |
    | --- |
    | $DataTool.oneOf("Hello", "Hey", "Hi", "Hi there", "Welcome")! Can I help you with any auto insurance questions today? |

    ![TextResponseNode](../images/02/014/image002.png)

## Test the dialogue

1. Use the **Try It Now** window to test out the random display for welcome messages.  Use the **End Session** button to bring up a new window.

    Did you get a different welcome message?  

    ![TestRandomWelcomes](../images/02/014/image003.png)