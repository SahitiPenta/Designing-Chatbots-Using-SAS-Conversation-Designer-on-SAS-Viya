![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# Create Dialogues: Claim Payment With SAS Code

- [Introduction](#introduction)
- [Test your SAS Code](#test-your-sas-code)
- [Log into SAS Studio](#log-into-sas-studio)
- [Add a dialogue for the Claim payment timeline Intent](#add-a-dialogue-for-the-claim-payment-timeline-intent)
- [Configure the SAS Code Data Provider node](#configure-the-sas-code-data-provider-node)
- [Configure the Text Response node](#configure-the-text-response-node)
- [Test the dialogue](#test-the-dialogue)


## Introduction

In this exercise you will continue to configure the **Auto Insurance Policies** bot from the previous exercises.  If you need to, please revisit the earlier instructions to complete those steps.

These steps will walk through creating a dialogue for the **Claim payment timeline** intent and will use SAS Code.

## Test your SAS Code

In this dialogue, we want to perform a simple date calculation for the response.  If the user asks when they can expect payment, I want to return the current date plus 30 days.  If the 30 days increment lands on a Saturday or Sunday, then I want to return the following Monday.  

Let's first figure out the SAS code using SAS Studio.

## Log into SAS Studio

1. Use the Application menu and select **Develop SAS Code**.

1. From the **Start Page**, select **Program in SAS**.

    ![SASProgram](../images/02/015/image001.png)

1. Copy and paste the following code into the **Code** tab.

    ```
    data work.claimpayment;
    format claimpaymentdate worddate28.;

    claimpaymentdate = intnx('DAY', date(), 30);
    
    if weekday(claimpaymentdate) = 7
        then claimpaymentdate = intnx('DAY', claimpaymentdate, 2);
    else if weekday(claimpaymentdate) = 1
        then claimpaymentdate = intnx('DAY', claimpaymentdate, 1);
        else claimpaymentdate = claimpaymentdate;

    run;
    ```

1. **Run** the code.  Examine the results.

    ![Results](../images/02/015/image002.png)

1. If you wanted to print these results to a JSON file and examine the results as the bot would expect the results, add this code.

    ```
    proc json out="/tmp/claimpayment.json" PRETTY TRIMBLANKS;
        export work.claimpayment;
    run;

    data _null_;
        infile '/tmp/claimpayment.json' lrecl=32560;
        input;
        put _infile_;
    run;
    ```

1. **Run** the newly added code.  Examine the **Log**.  This is the JSON output. 

    ![JSONResults](../images/02/015/image003.png)

1. Now let's go ahead and add this to our dialogue.  

## Add a dialogue for the Claim payment timeline Intent

1. Use the **Application Menu** to switch back to **Build Conversational Flows**.

1. From the **Dialogues** tab, click **New Dialogue**.  Name the dialogue **Claim payment timeline**.

1. Select the **User Input** node and be sure the **Claim payment timeline Intent** is configured in the right pane.  

    ![UserInput](../images/02/015/image004.png)

1. Next we will add the other two nodes in this dialogue:
    - **SAS Code Data Provider**
    - **Text Response**
  
    For the **SAS Code Data Provider** node, select the overflow menu (the vertical ellipsis) then **Add node below > Run Code > SAS Code Data Provider**.

    For the **Text Response** node, use the overflow menu then **Add node below > Bot Response > Text Response**.

    ![Flow](../images/02/015/image005.png)

## Configure the SAS Code Data Provider node

1. Let's configure the **SAS Code Data Provider** node.  We need to use the code that we ran in **SAS Studio**, with a small edit.  We will need to output the JSON to **_output** so that the results stream back to the current session.

    ```
    data work.claimpayment;
    format claimpaymentdate worddate28.;

    claimpaymentdate = intnx('DAY', date(), 30);
    
    if weekday(claimpaymentdate) = 7
        then claimpaymentdate = intnx('DAY', claimpaymentdate, 2);
    else if weekday(claimpaymentdate) = 1
        then claimpaymentdate = intnx('DAY', claimpaymentdate, 1);
        else claimpaymentdate = claimpaymentdate;

    run;

    proc json out=_output PRETTY TRIMBLANKS;
        export work.claimpayment;
    run;
    ```

1. For the **Output name** enter **ClaimOutput**.  Remember this is what the JSON object will be referenced as by the bot response.

    I also like to add the **Output** name to the name of the node.  That way when you are configuring other nodes you will not need to click off to recall what you named your output!

    ![SASCode](../images/02/015/image006.png)

## Configure the Text Response node

1. Now we need to configure the **Text Response** node.  Copy and paste this VTL code into the **Text Response editor**. 

    | Text Response |
    | --- |
    | You will be paid 30 days once the claim has been processed.  You can expect payment on or before this date:  $ClaimOutput.get("SASTableData+CLAIMPAYMENT").get(0).get("claimpaymentdate") | 

1. Take a look at how all of the pieces fit together.

    ![TextResponse](../images/02/015/image007.png)

## Test the dialogue

1. Use the **Try It Now** window to test our code and response!

    When will my claim be paid?

    ![TryItNow](../images/02/015/image008.png)

    >Hint: Use the i message to help debug your reference to the JSON object.  It prints nicely in the **Try It Now** window!