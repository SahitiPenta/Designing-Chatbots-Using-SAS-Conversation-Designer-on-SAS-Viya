![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# Create Dialogues: Invalid Dialogue

- [Introduction](#introduction)
- [Modify the Invalid Dialogue](#modify-the-invalid-dialogue)
- [Test the dialogue](#test-the-dialogue)



## Introduction

In this exercise you will continue to configure the **Auto Insurance Policies** bot from the previous exercises.  If you need to, please revisit the earlier instructions to complete those steps.

These steps will walk through creating a more robust dialogue for the **Invalid Dialogue**.

## Modify the Invalid Dialogue

1. From the **Dialogues** tab, click **Invalid Dialogue**.  Select the first node **First Invalid Event** and name it:

    ```
    Can’t Match User Input.
    ```

    ![FirstInvalid](../images/02/01A/image001.png)

1. For the **First Bot Response Text Response** node, leave the default configuration.

1. Next, select the **First Bot Response Text Response** node and add below another **Invalid Dialogue** node.  Name it:

    ```
    Can’t Match, Second Time
    ```

    ![SecondInvalid](../images/02/01A/image002.png)

1. Add a **Text Response** node below the **Can't Match, Second Time Invalid Dialogue** node.  Copy the following text:

    | Text Response |
    | --- |
    | I'm not sure what you mean. Would you mind explaining it differently for me? |

    ![SecondResponse](../images/02/01A/image003.png)

## Test the dialogue

1. Use the **Try It Now** window to see if the bot responds as expected.

    ![TryIt](../images/02/01A/image004.png)