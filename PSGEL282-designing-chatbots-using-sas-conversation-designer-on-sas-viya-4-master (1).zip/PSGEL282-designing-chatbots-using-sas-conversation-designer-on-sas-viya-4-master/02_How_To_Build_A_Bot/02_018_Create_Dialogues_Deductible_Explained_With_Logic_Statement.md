![Global Enablement & Learning](https://gelgitlab.race.sas.com/GEL/utilities/writing-content-in-markdown/-/raw/master/img/gel_banner_logo_tech-partners.jpg)

# Create Dialogues: Deductible Explained With Logic Statement

- [Introduction](#introduction)
- [Add a dialogue for the Deductible explained Intent](#add-a-dialogue-for-the-deductible-explained-intent)
- [Configure the User Input node](#configure-the-user-input-node)
- [Configure the Text Response node](#configure-the-text-response-node)
- [Configure the Text Input node](#configure-the-text-input-node)
- [Configure the Logic Statement and Else nodes](#configure-the-logic-statement-and-else-nodes)
- [Configure the Logic Statement Text Response node](#configure-the-logic-statement-text-response-node)
- [Configure the Else Text Response node](#configure-the-else-text-response-node)
- [Test the dialogue](#test-the-dialogue)


## Introduction

In this exercise you will continue to configure the **Auto Insurance Policies** bot from the previous exercises.  If you need to, please revisit the earlier instructions to complete those steps.

These steps will walk through creating a dialogue for the **Deductible explained** intent with a **Logic Statement** node and **Text Responses**.

## Add a dialogue for the Deductible explained Intent

1. From the **Dialogues** tab, click **New Dialogue**.  Name the dialogue **Deductible explained**.

1. In this dialogue we will need to add several nodes:
    - **Text Response** node
    - **Text Input** node
    - **Logic Statement** node (default split)
    - Two **Text Response** nodes

    From the **User Input** node, use the overflow menu (the vertical ellipsis) then **Add node below > Bot Response > Text Response**.

    From the **Text Response** node, use the overflow menu then **Add node below > User Input > Text Input**.

    From the **Text Input** node, use the overflow menu then **Add node below > Run Code > Logic Statement**.

    Then for each of the **Logic Statement** nodes, use the overflow menu then **Add node below > Bot Response > Text Response**.

    ![DeductibleDialogue](../images/02/018/image001.png)

## Configure the User Input node

1. With the **User Input** node selected, use the right pane to configure this dialogue to the matching **Deductible explained** intent.

    ![UserInput](../images/02/018/image002.png)

## Configure the Text Response node

1. With the **Text Response** node selected, paste the below code into the editor.

    | Text Response |
    | --- |
    | A deductible is the amount of the loss that you are responsible for paying.  Do you have coverage for more than auto with us?  Home, renters, fire? (Y/N) |

## Configure the Text Input node

1. With the **Text Input** node selected, enter **MoreThanAuto** as the **Parameter name**.

    Remember my trick, copy the parameter name to the name of the node so it's easy to remember the node's output.

    ![TextInput](../images/02/018/image003.png)

## Configure the Logic Statement and Else nodes

1. In this example, we will perform a rudimentary **Text Input** and matching scenario where we are going to rely on the user to follow instructions to enter a capital **Y**.

    With the **Logic Statement** node selected, enter this condition. 

    | Logic Statement |
    | --- |
    | $MoreThanAuto == "Y" |

    >Hint:  Notice that it's easy to understand that the **$MoreThanAuto** parameter is being set in our **Text Input** node with our naming convention trick.

    ![LogicStatement](../images/02/018/image004.png)

1. No configuration is required for the **Else** node.  This branch will capture any unmatched flows.

## Configure the Logic Statement Text Response node

1. Select the **Text Response** node that falls under the **Logic Statement** node.  Paste this code in the editor.

    Notice that this response is using VTL's **$NumberTool.currency()** function.  Could you format the numbers using a simple dollar sign?

    | Text Response |
    | --- |
    | Since you have more than just auto coverage with us your deductible will be lower and most likely between $NumberTool.currency(500) and $NumberTool.currency(750). |

    ![YesTextResponse](../images/02/018/image005.png)

## Configure the Else Text Response node

1. Select the **Text Response** node that falls under the **Else** node.  Past this code into the editor.

    | Text Response |
    | --- |
    | With only auto coverage, depending on your accident history your dedductible could be between $NumberTool.currency(1000) and $NumberTool.currency(1500). |

    ![ElseResponse](../images/02/018/image006.png)

## Test the dialogue

1. Use the **Try It Now** window to test the logic statement.  

1. For extra credit, try figuring out if you can make the matching more robust.

    ![TryItNow](../images/02/018/image007.png)